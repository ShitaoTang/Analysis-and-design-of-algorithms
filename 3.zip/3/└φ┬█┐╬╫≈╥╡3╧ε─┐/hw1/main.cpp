#include <iostream>
#include <vector>

int max_tower_height = 0;
int n;

struct Stone
{
    int height; //石块的厚度
    int max_height; //石块可存在的最大高度
    int num;    //石块的数量
};
std::vector<Stone> st;

int dfs(int cur_height)
{
    for(int i = 0; i < n; ++i)
    {
        if(st[i].num && st[i].height + cur_height <= st[i].max_height)  //若当前的石块仍有余且堆上去之后的高度不超过最大存在高度
        {
            --st[i].num;    //消耗一块石头
            cur_height += st[i].height; //增加高度
            max_tower_height = std::max(max_tower_height, cur_height);  //更新可建最大高度
            dfs(cur_height);
            cur_height -= st[i].height; //回退高度
            ++st[i].num;    //补偿石头数量
        }
    }
}

int main()
{
    std::cin >> n;
    st.resize(n);
    for(auto& i: st)
        std::cin >> i.height >> i.max_height >> i.num;

    dfs(0);
    std::cout<<max_tower_height;
}