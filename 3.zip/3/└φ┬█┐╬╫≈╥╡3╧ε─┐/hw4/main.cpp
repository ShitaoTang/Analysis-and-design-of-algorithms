#include <iostream>
#include <vector>

const int MAXNUM = 11;
int maze[MAXNUM][MAXNUM];	//迷宫矩阵
bool isvisited[MAXNUM][MAXNUM];	//标记格子是否被访问过
std::pair<int, int> start;	//起点
int num_black = 0;		//最多能够走过的黑色方格个数

int next[][2] =
{
    {0, 1},		//右
    {0, -1},	//左
    {1, 0},		//下
    {-1, 0}		//上
};

inline bool is_out_range(int x, int y, int n)
{
    return x < 0 || x >= n || y < 0 || y >= n;
}

void dfs(int x, int y, int cnt)
{
    if (!isvisited[x][y] && (maze[x][y] == 1 || maze[x][y] == 9))	//如果当前格子没有被访问过且是黑色的
    {
        isvisited[x][y] = true;			//标记已经访问
        ++cnt;						//累加黑色方格数
        num_black = std::max(num_black, cnt);	//更新最多能够走过的黑色方格数

        for (int i = 0; i < 4; ++i)
        {
            int new_x = x + next[i][0];	//更新下一步走的位置
            int new_y = y + next[i][1];

            if (!is_out_range(new_x, new_y, MAXNUM))
                dfs(new_x, new_y, cnt);	//进行下一步搜索
        }

        isvisited[x][y] = false;			//回溯，删除访问记录
    }
}

int main()
{
    for (int i = 0; i < MAXNUM; ++i)
        for (int j = 0; j < MAXNUM; ++j)
        {
            maze[i][j] = 2;
            isvisited[i][j] = false;
        }

    int n, m;
    std::cin >> n >> m;
    getchar();

    char c;
    int i = 0, j = 0;
    for (i = 0; i < m; ++i)
    {
        for (j = 0; j < n; ++j)
        {
            c = getchar();
            if (c == '#')
                maze[i][j] = 0;      //白色方格
            else if (c == '.')
                maze[i][j] = 1;      //黑色方格
            else if (c == '@')
            {
                maze[i][j] = 9;
                start = std::make_pair(i, j);   //人的起始位置
            }
            else if (c != '\n') // 处理非法字符
            {
                std::cout << "Invalid input!" << std::endl;
                return 0;
            }
        }
        getchar();                      // 吃掉多余的回车符
    }


    dfs(start.first, start.second, 0);	//从起点开始搜索

    std::cout << num_black + 1 << std::endl;     //初始位置即黑色方格

    return 0;
}