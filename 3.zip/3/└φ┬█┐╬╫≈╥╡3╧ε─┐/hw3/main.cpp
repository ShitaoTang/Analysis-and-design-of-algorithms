#include <iostream>
#include <vector>

const int MAXNUM = 11;
int maze[MAXNUM][MAXNUM];	//迷宫矩阵
bool isvisited[MAXNUM][MAXNUM];	//标记格子是否被访问过
std::pair<int, int> Entrance;	//入口和出口
std::vector<std::vector<std::pair<int, int>>> solutions;	//所有可行解的集合
int next[][2] =
    {
        {0, 1},		//右
        {0, -1},	//左
        {1, 0},		//下
        {-1, 0}		//上
    };

inline bool is_out_range(int x, int y, int n)
{
    return x < 0 || x >= n || y < 0 || y >= n;
}

void dfs(int x, int y, std::vector<std::pair<int, int>>& path)
{
    if (maze[x][y] == 2 || isvisited[x][y])		//碰到墙壁或已走过这个位置
    {
        solutions.push_back(path);
        return;
    }

    isvisited[x][y] = true;	//处理当前节点，先标记访问过
    path.push_back(std::make_pair(x, y));

    for (int i = 0; i < 4; ++i)
    {
        int new_x = x + next[i][0];	//更新下一步走的位置
        int new_y = y + next[i][1];

        if (!is_out_range(x, y, MAXNUM))
            dfs(new_x, new_y, path);
    }

    isvisited[x][y] = false;	//删除访问记录
    path.pop_back();
}

int main()
{
    for (int i = 0; i < MAXNUM; ++i)
        for (int j = 0; j < MAXNUM; ++j)
        {
            maze[i][j] = 2;
            isvisited[i][j] = false;
        }

    int n = 9;
    std::cout << "input a 9×9 maze:\n";	//输入迷宫
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            std::cin >> maze[i][j];

    //输入入口和出口坐标
    std::cout << "input the coordinates of entrance and exit:\n";
    std::cin >> Entrance.first >> Entrance.second >> Exit.first >> Exit.second;

    std::vector<std::pair<int, int>> path;
    dfs(Entrance.first, Entrance.second,  path);

    std::cout << "There are " << solutions.size() << " possible paths.\n";
    int min_len = 0;
    std::vector<std::pair<int, int>> shortest_path;

    int num_paths = solutions.size();
    for (int i = 0; i < num_paths; ++i)	//遍历所有可能的路径
    {
        std::cout << "Solution " << i + 1 << ":\n";
        for (int j = 0; j < n; ++j)		//遍历迷宫矩阵，若某点存在于路径中，打印'*'
        {
            for (int k = 0; k < n; ++k)
            {
                if (maze[j][k] == 2)
                    std::cout << " \033[31m# \033[0m";
                else if (std::find(solutions[i].begin(), solutions[i].end(), std::make_pair(j, k)) != solutions[i].end())
                    std::cout << " * ";
                else
                    std::cout << "   ";
            }
            std::cout << std::endl;
        }

        std::cout << "Length: " << solutions[i].size() << std::endl;
        std::cout << "Path: ";
        for (auto& x : solutions[i])
        {
            std::cout << "(" << x.first << ", " << x.second << ")";
            if(&x != &solutions[i].back())
                std::cout << " → ";
        }
        std::cout << "\n\n--------------------------------------------------------------\n\n";

        if (solutions[i].size() < min_len)	//更新最短路径
        {
            min_len = solutions[i].size();
            shortest_path = solutions[i];
        }
    }

    std::cout << "shortest path's length is " << shortest_path.size();
    std::cout << "\nshorest path: ";
    for(auto& x:shortest_path)
    {
        std::cout << "(" << x.first << ", " << x.second << ")";
        if (&x != &shortest_path.back())
            std::cout << " → ";
    }
    std::cout << std::endl;

    return 0;
}