#include <iostream>
#include <string>
#include <algorithm>

std::string s[5];
const int MAX_STEPS = 16;
int next[][2] =
    {
        {0, 0},		//自身
        {0, 1},		//右
        {0, -1},	//左
        {1, 0},		//下
        {-1, 0}		//上
    };

bool check()
{
    char c = s[0][0];
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j)
            if (s[i][j] != c)
                return false;
    return true;
}

void flip(int n)	//对n及其周边的棋子进行翻转
{
    int x = n / 4;	//将输入的数字转化为对应位置坐标
    int y = n % 4;

    //依次对当前位置、右、左、下、上的五个棋子进行翻转
    for (int i = 0; i < 5; ++i)
    {
        int new_x = x + next[i][0];
        int new_y = y + next[i][1];

        if (new_x >= 0 && new_x < 4 && new_y >= 0 && new_y < 4)
            s[new_x][new_y] = (s[new_x][new_y] == 'b' ? 'w' : 'b');
    }
}

//n为当前要处理的位置，steps是已经翻转的棋子个数
int dfs(int n, int steps)
{
    if (check())
        return steps;
    if (n > MAX_STEPS)		//最多把所有棋子翻转一遍
        return MAX_STEPS;

    int steps1 = dfs(n + 1, steps);    //先不翻转，搜索下一颗棋子
    flip(n);   //若翻转了当前位置，是否可找到一组解
    int steps2 = dfs(n + 1, steps + 1);   //翻转，搜索下一颗棋子
    flip(n);   //把当前位置棋子翻转回来，即表示当前位置的棋子不翻转

    return std::min(steps1, steps2);
}

int main()
{
    for (int i = 0; i < 4; ++i)
        std::cin >> s[i];
    int min_steps = dfs(0, 0);

    if (min_steps != MAX_STEPS)
        std::cout << min_steps << std::endl;
    else
        std::cout << "Impossible!\n";	//无解

    return 0;
}